import { getDatabase } from 'firebase/database';
import { initializeApp } from "firebase/app";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyC51tsfS9p63TXmqtGeAlpXQX8D6fqgwNA",
    authDomain: "meeting-form-3aec1.firebaseapp.com",
    projectId: "meeting-form-3aec1",
    storageBucket: "meeting-form-3aec1.appspot.com",
    messagingSenderId: "502805513750",
    appId: "1:502805513750:web:212aa914d33d0015741737",
    measurementId: "G-89YDESGSGW"
  };

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);