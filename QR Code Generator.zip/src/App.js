import logo from './logo.svg';
import './App.css';
import QRCode from 'qrcode.react';
import { db } from './utils/firebase';

function App() {
  return (
    <div style={{marginTop:200, display: "flex", flexDirection:"row", paddingLeft:20}}>
      <QRCode value="https://marvelous-centaur-64f168.netlify.app" style={{marginRight:50}} />
        <p>Meeting Sign-Up Form</p>
    </div>
  );
}

export default App;
