from django.urls import path
from . import views

#include admin site path later
urlpatterns = [
    path('', views.index, name='index'),
]