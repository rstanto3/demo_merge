import React, {useState} from 'react';
// import ReactDOM from 'react-dom/client';
import './App.css';

class NameForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      firstName: '',
      lastName: '',
      meetingName: '',
      date: ''
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    const name = event.target.name;
    const value = event.target.value;
    this.setState({
      [name]: value
    });
  }


  //This occurs after we hit submit, created an alert to make sure it saved the data at least for the alert
  //probably where we want to save to the database from
  handleSubmit(event) {
    alert(this.state.firstName + ' ' + this.state.lastName + 
      ' signed in for ' + this.state.meetingName + ' on ' + this.state.date);
    event.preventDefault();
  }

  render() {
    const current = new Date();
    this.state.date = (current.getMonth() + 1) + '/' + current.getDate() + '/' + current.getFullYear();
    return(
      <div id="form">
      <h1>Meeting Sign-Up Form</h1>
      <form onSubmit={this.handleSubmit}>
        <label>
          First Name: 
          <input type="text" name="firstName" value={this.state.firstName}
            onChange={this.handleChange} />
        </label>
        <label>
          Last Name: 
          <input type="text" name="lastName" value={this.state.lastName}
            onChange={this.handleChange} /> 
        </label>
        <label>
          Meeting Name: 
          <input type="text" name="meetingName" value={this.state.meetingName}
            onChange={this.handleChange} />
        </label>
        <input type="submit" value="Submit" />
      </form>
    </div>
    )
  }
}

export default NameForm;
